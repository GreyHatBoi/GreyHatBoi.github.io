var parent = require('../../es/promise/finally');

module.exports = parent;
