var parent = require('../../es/reflect/delete-property');

module.exports = parent;
