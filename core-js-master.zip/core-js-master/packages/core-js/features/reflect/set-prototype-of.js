var parent = require('../../es/reflect/set-prototype-of');

module.exports = parent;
