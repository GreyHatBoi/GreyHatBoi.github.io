var parent = require('../../es/reflect/construct');

module.exports = parent;
