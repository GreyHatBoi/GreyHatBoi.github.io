var parent = require('../../es/number/is-finite');

module.exports = parent;
