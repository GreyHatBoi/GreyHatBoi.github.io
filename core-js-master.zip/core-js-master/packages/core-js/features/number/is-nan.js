var parent = require('../../es/number/is-nan');

module.exports = parent;
