var parent = require('../../es/number/min-safe-integer');

module.exports = parent;
