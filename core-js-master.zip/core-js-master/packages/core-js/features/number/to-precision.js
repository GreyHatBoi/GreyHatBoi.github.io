var parent = require('../../es/number/to-precision');

module.exports = parent;
