var parent = require('../../es/number/is-integer');

module.exports = parent;
