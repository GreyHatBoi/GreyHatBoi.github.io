var parent = require('../../es/number/max-safe-integer');

module.exports = parent;
