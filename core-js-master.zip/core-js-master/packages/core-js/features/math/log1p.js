var parent = require('../../es/math/log1p');

module.exports = parent;
