var parent = require('../../es/math/hypot');

module.exports = parent;
