require('../../modules/esnext.math.clamp');
var path = require('../../internals/path');

module.exports = path.Math.clamp;
