var parent = require('../../es/math/log10');

module.exports = parent;
