var parent = require('../../../es/array/virtual/slice');

module.exports = parent;
