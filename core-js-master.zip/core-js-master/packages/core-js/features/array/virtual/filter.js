var parent = require('../../../es/array/virtual/filter');

module.exports = parent;
