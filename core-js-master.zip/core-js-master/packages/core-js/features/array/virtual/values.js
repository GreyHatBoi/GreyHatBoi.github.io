var parent = require('../../../es/array/virtual/values');

module.exports = parent;
