var parent = require('../../../es/array/virtual');
require('../../../modules/esnext.array.at');
require('../../../modules/esnext.array.filter-out');
require('../../../modules/esnext.array.unique-by');

module.exports = parent;
