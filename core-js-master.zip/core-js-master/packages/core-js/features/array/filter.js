var parent = require('../../es/array/filter');

module.exports = parent;
