var parent = require('../../es/array/concat');

module.exports = parent;
