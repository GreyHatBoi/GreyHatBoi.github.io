var parent = require('../../es/array/fill');

module.exports = parent;
