var parent = require('../../es/array/some');

module.exports = parent;
