var parent = require('../../es/instance/ends-with');

module.exports = parent;
