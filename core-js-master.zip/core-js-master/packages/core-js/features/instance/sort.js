var parent = require('../../es/instance/sort');

module.exports = parent;
