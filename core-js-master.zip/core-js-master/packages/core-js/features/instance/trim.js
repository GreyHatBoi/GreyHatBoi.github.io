var parent = require('../../es/instance/trim');

module.exports = parent;
