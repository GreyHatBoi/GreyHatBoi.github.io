var parent = require('../../es/instance/trim-left');

module.exports = parent;
