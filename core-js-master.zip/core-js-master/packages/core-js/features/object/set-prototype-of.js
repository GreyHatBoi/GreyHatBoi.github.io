var parent = require('../../es/object/set-prototype-of');

module.exports = parent;
