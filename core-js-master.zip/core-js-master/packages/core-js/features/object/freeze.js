var parent = require('../../es/object/freeze');

module.exports = parent;
