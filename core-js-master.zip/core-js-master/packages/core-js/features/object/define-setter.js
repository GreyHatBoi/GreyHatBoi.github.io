var parent = require('../../es/object/define-setter');

module.exports = parent;
