require('../modules/web.dom-collections.iterator');
require('../modules/es.string.iterator');
var getIteratorMethod = require('../internals/get-iterator-method');

module.exports = getIteratorMethod;
