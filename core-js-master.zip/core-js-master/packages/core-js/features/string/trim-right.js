var parent = require('../../es/string/trim-right');

module.exports = parent;
