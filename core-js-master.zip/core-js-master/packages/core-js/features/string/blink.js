var parent = require('../../es/string/blink');

module.exports = parent;
