var parent = require('../../es/string/big');

module.exports = parent;
