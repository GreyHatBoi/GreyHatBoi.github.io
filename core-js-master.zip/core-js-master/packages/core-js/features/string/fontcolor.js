var parent = require('../../es/string/fontcolor');

module.exports = parent;
