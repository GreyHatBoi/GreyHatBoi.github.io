var parent = require('../../es/string/repeat');

module.exports = parent;
