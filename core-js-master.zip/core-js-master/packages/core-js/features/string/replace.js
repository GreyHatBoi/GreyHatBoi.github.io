var parent = require('../../es/string/replace');

module.exports = parent;
