var parent = require('../../es/string/fontsize');

module.exports = parent;
