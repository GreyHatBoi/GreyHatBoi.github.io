var parent = require('../../stable/dom-collections');

module.exports = parent;
