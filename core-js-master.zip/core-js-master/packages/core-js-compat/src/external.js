'use strict';
module.exports = {
  modules: {
    chrome: '61',
    edge: '16',
    firefox: '60',
    safari: '10.1',
  },
};
